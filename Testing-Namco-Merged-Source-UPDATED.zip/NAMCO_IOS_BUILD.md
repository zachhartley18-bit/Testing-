# Namco Museum — iOS build integration

This integration adds Namco Museum as a third **iOS-only** title on the MC3
runtime. It consumes the already-generated Namco recompilation output; it does
not run another lift and does not build a desktop/PC target.

## What is included

- `namco/generated/`: the 23 existing lifted C chunks, function declarations,
  runtime type header, unresolved stubs, and dispatch table.
- `config/namco/`: Namco's XBE identity, USA edition fingerprint, game config,
  and iOS app identity.
- `src/games/namco/recomp_manual.c`: generic manual-override and diagnostics
  layer, with no DUB Edition-specific patches.
- A per-thread `g_eflags` state in the shared Xbox memory runtime. Namco's
  generated code already implements `pushfd`/`popfd`, flag publication across
  calls, x87 precision control, and caller-cleanup indirect-call dispatch in
  its own `recomp_types.h`; this patch supplies the missing runtime storage.
- `.github/workflows/namco-ios-build.yml`: GitHub `xcode-27` arm64 workflow that compiles Release for iOS, packages an
  unsigned IPA, and uploads it as an artifact.

## Build in GitHub Actions

1. Apply these integration files to the MC3 repository and commit/push them.
2. Open **Actions → Namco Museum iOS IPA → Run workflow**.
3. Download the `namco-museum-ios-*` artifact from the completed run.
4. Sign the unsigned IPA with your sideloading tool.

The workflow uses the existing lifted C; no XBE or game assets are uploaded to
GitHub or embedded in the IPA.

## Put the game files on the device

The app exposes its Documents folder in the iOS Files app. Extract your own
Namco Museum disc and copy the contents so the app sees:

```text
On My iPhone/iPad/
  Namco Museum/
    Documents/
      game/
        default.xbe
        data0.blt
        *.wmv
```

The `game/` folder can also be named `game-usa/`. Keep the XBE and its companion
files together. The IPA contains the runtime, not the game disc.

## Current technical boundary

- The supplied XBE is North American retail, title ID `0x4E4D0007`, XDK 4831,
  entry point `0x0059F293`, and 6,955,008 bytes. Its exact FNV-1a fingerprint is
  checked at boot.
- The existing output has 5,593 dispatch entries and 213 unresolved stubs.
  Those stubs may affect boot or later game behavior; a successful IPA build
  does not prove the title boots or plays correctly.
- Namco's title-specific D3D push-buffer and frame-time addresses have not been
  identified. The MC3-only diagnostics are disabled rather than pointed at
  guessed addresses. The shared NV2A/OpenGL ES runtime remains in place.
- The workflow builds only the iOS device app (arm64, Release). It does not
  build or test a PC target, and it cannot test actual gameplay on a device.

## Why the EFLAGS code is not copied wholesale

The Namco generated C and its accompanying `recomp_types.h` are an ABI pair.
That header already declares thread-local `g_eflags` and defines the exact
`recomp_pushfd()` / `recomp_popfd()` semantics expected by the generated C.
The MC3 runtime already has thread-local `g_df`; the integration adds the
missing thread-local EFLAGS image initialized to the x86 baseline `0x202`.
This avoids replacing the current MC3 register model or its newer runtime
scheduling/atomic behavior with an older header wholesale.
