/* Namco Museum -- addresses confirmed from the supplied XBE analysis.
 * MC3-specific diagnostic addresses are deliberately disabled until found
 * in Namco's code. Do not guess D3D push-buffer or frame-time globals.
 */
#pragma once
#define MC3_ADDR_PB_STATE    0u
#define MC3_ADDR_FRAME_TIME  0u
#define MC3_CODE_LO          0x00011000u
#define MC3_CODE_HI          0x0075DE20u
#define MC3_GAME_DEFAULTS(X)
