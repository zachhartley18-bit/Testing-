/* Generated from the supplied Namco Museum retail default.xbe. */
#pragma once
#define MC3_XBE_ENTRY_POINT 0x0059F293u
#define MC3_XBE_TITLE_ID    0x4E4D0007u
#define MC3_XBE_TITLE_NAME  "NamcoMuseum"
#define MC3_XBE_SIZE        6955008u
#define MC3_XBE_FNV64       0xb8e4abbae4436903ull
#define MC3_XBE_REGION      0x1u
#define MC3_XBE_VERSION     0x1u
#define MC3_EDITION         "usa"
