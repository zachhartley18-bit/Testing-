/* This lift is tied to the supplied North American retail XBE. */
#pragma once
#define MC3_XBE_EDITIONS(X) \
    X("usa", 0xb8e4abbae4436903ull, 0x1u, 0x1u)
