/* Namco Museum x86 port-I/O bridge.
 *
 * xemu is built on QEMU's port-I/O address space. The static MC3/XboxRecomp
 * app does not embed a QEMU machine, so this file exposes a narrow binding
 * point for an xemu host to provide its cpu_in and cpu_out dispatchers.
 *
 * Until a host binds those callbacks, reads follow QEMU's unassigned-I/O
 * behavior (all bits set) and writes are ignored. Unbound accesses are logged
 * once per port/direction to make missing device models visible. This is a
 * link-complete fallback, not an emulation of the Xbox chipset's devices.
 */
#include "xbox_port_io.h"

#include <stdio.h>
#include <string.h>

static xbox_port_read_backend_t s_read_backend;
static xbox_port_write_backend_t s_write_backend;
static void *s_backend_opaque;
static unsigned char s_unbound_read_logged[65536];
static unsigned char s_unbound_write_logged[65536];

static uint32_t width_mask(unsigned width)
{
    switch (width) {
    case 1: return 0x000000FFu;
    case 2: return 0x0000FFFFu;
    case 4: return 0xFFFFFFFFu;
    default: return 0u;
    }
}

void xbox_port_io_bind_xemu(xbox_port_read_backend_t read_backend,
                            xbox_port_write_backend_t write_backend,
                            void *opaque)
{
    s_read_backend = read_backend;
    s_write_backend = write_backend;
    s_backend_opaque = opaque;
}

uint32_t xbox_PortIn(uint32_t port, int width)
{
    uint32_t mask = width_mask((unsigned)width);
    uint32_t value;

    if (mask == 0u) {
        fprintf(stderr, "[xbox-port] invalid IN width %d at port 0x%04X\n",
                width, (unsigned)(port & 0xFFFFu));
        return 0xFFFFFFFFu;
    }

    if (s_read_backend) {
        value = s_read_backend(s_backend_opaque, port & 0xFFFFu,
                               (unsigned)width);
        return value & mask;
    }

    port &= 0xFFFFu;
    if (!s_unbound_read_logged[port]) {
        s_unbound_read_logged[port] = 1;
        fprintf(stderr,
                "[xbox-port] unbound IN port=0x%04X width=%d; returning all-ones (bind xemu I/O backend)\n",
                (unsigned)port, width);
    }
    return mask;
}

void xbox_PortOut(uint32_t port, uint32_t value, int width)
{
    uint32_t mask = width_mask((unsigned)width);

    if (mask == 0u) {
        fprintf(stderr, "[xbox-port] invalid OUT width %d at port 0x%04X\n",
                width, (unsigned)(port & 0xFFFFu));
        return;
    }

    port &= 0xFFFFu;
    value &= mask;
    if (s_write_backend) {
        s_write_backend(s_backend_opaque, port, value, (unsigned)width);
        return;
    }

    if (!s_unbound_write_logged[port]) {
        s_unbound_write_logged[port] = 1;
        fprintf(stderr,
                "[xbox-port] unbound OUT port=0x%04X width=%d value=0x%08X; ignored (bind xemu I/O backend)\n",
                (unsigned)port, width, (unsigned)value);
    }
}
