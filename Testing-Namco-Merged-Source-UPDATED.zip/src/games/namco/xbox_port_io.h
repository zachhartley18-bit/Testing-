#ifndef NAMCO_XBOX_PORT_IO_H
#define NAMCO_XBOX_PORT_IO_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Backend callbacks use the same width contract as xemu/QEMU's cpu_in* and
 * cpu_out* port-I/O entry points: width is exactly 1, 2, or 4 bytes. */
typedef uint32_t (*xbox_port_read_backend_t)(void *opaque,
                                             uint32_t port,
                                             unsigned width);
typedef void (*xbox_port_write_backend_t)(void *opaque,
                                          uint32_t port,
                                          uint32_t value,
                                          unsigned width);

/* Bind these callbacks to the host emulator's port-I/O address space before
 * guest execution. In an xemu/QEMU host, callbacks should dispatch to
 * cpu_inb/cpu_inw/cpu_inl and cpu_outb/cpu_outw/cpu_outl respectively. */
void xbox_port_io_bind_xemu(xbox_port_read_backend_t read_backend,
                            xbox_port_write_backend_t write_backend,
                            void *opaque);
/* Defined by the optional xemu/QEMU-side adapter translation unit. */
void xbox_port_io_install_xemu_backend(void);

/* Called by lifted x86 IN/OUT instructions. */
uint32_t xbox_PortIn(uint32_t port, int width);
void xbox_PortOut(uint32_t port, uint32_t value, int width);

#ifdef __cplusplus
}
#endif

#endif /* NAMCO_XBOX_PORT_IO_H */
