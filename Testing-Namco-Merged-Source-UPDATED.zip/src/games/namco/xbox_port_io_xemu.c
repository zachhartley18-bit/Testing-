/* Optional xemu/QEMU host adapter.
 *
 * Compile this file into an xemu build (not the standalone iOS app), where
 * QEMU's exec/ioport.h and the Xbox machine's address_space_io are available.
 * The cpu_in and cpu_out calls dispatch through xemu's registered MemoryRegion
 * port handlers, including the Xbox LPC/ISA and other device models.
 */
#include "xbox_port_io.h"
#include "exec/ioport.h"

static uint32_t xemu_port_read(void *opaque, uint32_t port, unsigned width)
{
    (void)opaque;
    switch (width) {
    case 1: return cpu_inb(port);
    case 2: return cpu_inw(port);
    case 4: return cpu_inl(port);
    default: return 0xFFFFFFFFu;
    }
}

static void xemu_port_write(void *opaque, uint32_t port,
                            uint32_t value, unsigned width)
{
    (void)opaque;
    switch (width) {
    case 1: cpu_outb(port, (uint8_t)value); break;
    case 2: cpu_outw(port, (uint16_t)value); break;
    case 4: cpu_outl(port, value); break;
    default: break;
    }
}

/* Call after xemu has initialized its I/O address space and Xbox devices. */
void xbox_port_io_install_xemu_backend(void)
{
    xbox_port_io_bind_xemu(xemu_port_read, xemu_port_write, 0);
}
