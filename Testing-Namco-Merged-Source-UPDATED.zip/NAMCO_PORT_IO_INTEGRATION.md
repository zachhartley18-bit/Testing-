# Namco Museum port-I/O bridge

The lifted Namco code calls `xbox_PortIn(port, width)` and
`xbox_PortOut(port, value, width)` for x86 `IN`/`OUT` instructions.

## Standalone MC3/XboxRecomp build

`src/games/namco/xbox_port_io.c` supplies the two symbols required by the
lifted code. It provides a callback binding point (`xbox_port_io_bind_xemu`)
and a safe, visible fallback for unbound ports: reads return all bits set,
matching QEMU's unassigned I/O-space read behavior; writes are ignored. Every
unbound port/direction is logged once. This fallback is link-complete but does
not emulate a device model.

## Binding an xemu host

`src/games/namco/xbox_port_io_xemu.c` is the optional xemu/QEMU-side adapter.
It is intentionally excluded from the standalone iOS CMake target because
this repository does not embed or initialize an xemu/QEMU machine. Add this
adapter to the xemu host build, then call
`xbox_port_io_install_xemu_backend()` after xemu has initialized
`address_space_io` and its Xbox devices. It forwards 8-, 16-, and 32-bit
operations to QEMU's `cpu_inb/cpu_inw/cpu_inl` and
`cpu_outb/cpu_outw/cpu_outl` functions.

The adapter must run in a process containing the xemu machine/device model.
It cannot be activated merely by linking the standalone Namco iOS app against
this repository's current XboxRecomp runtime.

## Performance counters

Namco defines the three shared MC3 performance globals consumed by
`src/main.c`. They initialize to zero; no Namco-specific vblank or game-loop
wrappers have been established yet, so the counters are not claimed to measure
Namco frame activity.
