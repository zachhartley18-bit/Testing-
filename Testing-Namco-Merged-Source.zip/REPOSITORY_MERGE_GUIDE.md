# Testing- repository merge guide

This bundle contains the extracted `mcdub3-nx-ios-v1.1.0` project with the Namco Museum iOS integration applied.

## Important: preserve existing repository files

The existing `Testing-` repository has additional top-level material and workflows. When copying this bundle into that repository, **merge/replace files in place; do not delete the existing repository or its `.github/workflows` directory**.

- Keep the existing MC3 IPA workflow(s) already in `Testing-`.
- Add `.github/workflows/namco-ios-build.yml` from this bundle alongside them.
- Existing MC3-specific workflow files should remain unchanged. If a same-named file exists in both places, keep the repository's existing version unless you intentionally want to update it.
- Keep the existing `mc3-self-contained-ipa.patch`, `namco-recompile/`, and other root-level files from `Testing-` unless you have independently confirmed they are obsolete.

This is a merged source tree, not a verified Xcode build. The Namco workflow still needs to run in GitHub Actions to confirm the actual Xcode 27 build.
