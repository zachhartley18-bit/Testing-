# Namco Museum generated source

These are the existing generated files extracted from the user's
`namco-museum-xboxrecomp-results 2.zip` archive. No XBE, disc image, video,
asset, or other game data is included here.

- 23 `recomp_####.c` chunks
- `recomp_dispatch.c` (5,593 dispatch entries)
- `recomp_funcs.h`
- `recomp_stubs_unresolved.c` (213 unresolved-function stubs)
- `recomp_types.h` (iOS-adapted copy of the supplied generated ABI header)
- `recomp_types.original.h` (unmodified header from the supplied archive)

The active `recomp_types.h` preserves the supplied Namco ABI, including
thread-local EFLAGS state, `recomp_pushfd()` / `recomp_popfd()`, x87 precision
control, and caller-cleanup indirect-call helpers. Its only integration change
is the ARM64 unaligned-atomic fallback from the current MC3 runtime.

Original toolkit commit recorded by the archive:
`343b6d8901723b37ce568b2418c5df4e1fe1d223`.
