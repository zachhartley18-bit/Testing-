/* Midnight Club 3: DUB Edition Remix -- the guest addresses shared code
 * needs (src/main.c). Mapped from the DUB Edition's (config/dub/game.h)
 * with tools/match_lifts.py's Mapper, 2026-10-24: the same operand of the
 * twin instruction in identical functions. */
#pragma once

#define MC3_ADDR_PB_STATE    0x00422D80u   /* D3D's push-buffer state: 12 of 12 references agree */
#define MC3_ADDR_FRAME_TIME  0x004B2D70u   /* the game's frame time: 1 of 1 */
#define MC3_CODE_LO          0x00011000u   /* .text .. XPP (ends 0x004476C8) */
#define MC3_CODE_HI          0x00448000u

/* Settings this game starts with unless mcdub3remix_env.txt (or the
 * environment) says otherwise (src/main.c, set_runtime_defaults).
 * Merging draws with per-draw matrices off (Switch rain races, 2026-10-28):
 *   merging off                          1262 calls x 21 us, 20 fps
 *   merging + per-draw matrices          ~900 calls x 36 us, 17.5-18.5 fps
 *   merging, per-draw matrices off        975 calls x 20 us -- the cheapest
 * The Remix changes matrices often; each merged call with several matrix
 * sets uploads two 64-row uniform arrays, and Mesa resends the program's
 * whole uniform block for each. The DUB Edition keeps both on.
 * RECOMP_GL_CUBO=1: the vertex programs' 192 constants streamed through a
 * uniform buffer and bound by range -- not copied, 3 KB at a time, into the
 * driver's command stream at each of ~270 changes a rain frame. */
#define MC3_GAME_DEFAULTS(X) \
    X("RECOMP_GL_MERGE", "1") \
    X("RECOMP_GL_PERDRAW", "0") \
    X("RECOMP_GL_MERGE_KB", "256") \
    X("RECOMP_GL_CUBO", "1")          /* constants through a uniform buffer */ \
    X("RECOMP_GL_LEAN", "0")          /* uniforms all re-sent at a change: played better (2026-10-29) */ \
    X("RECOMP_GL_SMALL_SCALE", "1")   /* effect buffers at 1x: 1.5 cost 6 ms more GPU */ \
    X("MC3_REALTIME", "1")            /* races in real time below 30 fps: steadier (2026-11-02) */ \
    X("RECOMP_GL_EDGE_TRIM", "2")     /* the race frame's last columns: streaks at the right edge */ \
    X("RECOMP_GL_RT_EDGE", "1")       /* speed blur: no white lines at the picture's edges */ \
    X("RECOMP_GL_FILL_STEADY", "1")   /* loading screens: the 4:3 fill no longer flickers */ \
    X("RECOMP_GL_SHARPEN", "0.5")     /* CAS on, as the DUB Edition: played better (2026-10-29) */
