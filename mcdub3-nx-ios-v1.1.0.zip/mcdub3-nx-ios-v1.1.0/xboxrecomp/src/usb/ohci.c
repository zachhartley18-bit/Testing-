/*
 * ohci.c -- OHCI 1.0a host controller registers for the MCPX.
 *
 * See ohci.h for what this is and is not. The short version: enough for a
 * title's own USB driver to find a controller and a populated root hub port,
 * plus a trace of every register access, because what the driver does after
 * that decides how the rest gets built.
 */
#include "ohci.h"
#include "../platform/mmio_decode.h"
#include "../kernel/xbox_memory_layout.h"
#include "../kernel/kernel.h"
#include "usb_gamepad.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>

/* The runtime maps guest memory at a fixed host offset. */
extern ptrdiff_t xbox_GetMemoryOffset(void);

/* Calling the title's interrupt service routine.
 *
 * A recompiled function reads its arguments off the guest stack and keeps its
 * registers in thread-local storage, so it can only be called from a thread
 * that has both. xbox_worker_stack_alloc hands out a guest stack slice for
 * exactly this -- a host thread calling recompiled code -- and recomp_lookup
 * turns a guest address into something callable.
 */
typedef void (*recomp_func_t)(void);
extern recomp_func_t recomp_lookup(uint32_t xbox_va);
void xbox_gil_isr_begin(void);
void xbox_gil_isr_end(void);
extern int  xbox_worker_stack_alloc(void);
extern void xbox_worker_stack_free(int slot);
extern uint32_t xbox_GetConnectedInterrupt(uint32_t vector);

/* Declared in the generated runtime; thread-local, so the values below are
 * this thread's and not the guest thread's. */
#if defined(_MSC_VER)
#  define OHCI_TLS __declspec(thread)
#else
#  define OHCI_TLS __thread
#endif
extern OHCI_TLS uint32_t g_eax, g_ecx, g_edx, g_esp;
extern OHCI_TLS uint32_t g_ebx, g_esi, g_edi;
extern OHCI_TLS uint32_t g_fs_base;
extern uint32_t xbox_AllocThreadTib(void);

/* The vector XPP takes for USB0. HalGetInterruptVector(1) returns 1 here, and
 * the bus interrupt level is what the XDK passes. */
#define OHCI_VECTOR  1

/* ---- OHCI 1.0a operational registers, by byte offset ------------------- */
#define HcRevision              0x00
#define HcControl               0x04
#define HcCommandStatus         0x08
#define HcInterruptStatus       0x0C
#define HcInterruptEnable       0x10
#define HcInterruptDisable      0x14
#define HcHCCA                  0x18
#define HcPeriodCurrentED       0x1C
#define HcControlHeadED         0x20
#define HcControlCurrentED      0x24
#define HcBulkHeadED            0x28
#define HcBulkCurrentED         0x2C
#define HcDoneHead              0x30
#define HcFmInterval            0x34
#define HcFmRemaining           0x38
#define HcFmNumber              0x3C
#define HcPeriodicStart         0x40
#define HcLSThreshold           0x44
#define HcRhDescriptorA         0x48
#define HcRhDescriptorB         0x4C
#define HcRhStatus              0x50
#define HcRhPortStatus1         0x54
/* Through port 4. The root hub here reports two downstream ports, and the
 * driver reads four status registers regardless -- so the file has to cover
 * them or the last one falls outside the array and is answered by the
 * not-a-register path instead of by an empty port. Same value either way,
 * reached honestly. */
#define OHCI_REG_MAX            0x64

/* HcCommandStatus */
#define CS_HCR                  0x00000001u   /* host controller reset       */

/* HcInterruptStatus / Enable */
#define INTR_SO                 0x00000001u   /* scheduling overrun          */
#define INTR_WDH                0x00000002u   /* writeback done head         */
#define INTR_SF                 0x00000004u   /* start of frame              */
#define INTR_RD                 0x00000008u   /* resume detected             */
#define INTR_UE                 0x00000010u   /* unrecoverable error         */
#define INTR_FNO                0x00000020u   /* frame number overflow       */
#define INTR_RHSC               0x00000040u   /* root hub status change      */

/* HccaFrameNumber is at +0x80 and the done head at +0x84. Declared up here
 * because the register write handler retires the done list on a WDH ack. */
#define HCCA_DONE_HEAD 0x84
static void wr32(uint32_t va, uint32_t v);
#define INTR_MIE                0x80000000u   /* master interrupt enable     */

/* HcRhPortStatus */
#define PORT_CCS                0x00000001u   /* current connect status      */
#define PORT_PES                0x00000002u   /* port enable status          */
#define PORT_PSS                0x00000004u   /* port suspend status         */
#define PORT_PPS                0x00000100u   /* port power status           */
#define PORT_LSDA               0x00000200u   /* low speed device attached   */
#define PORT_CSC                0x00010000u   /* connect status change       */
#define PORT_PESC               0x00020000u   /* enable status change        */
#define PORT_PRSC               0x00100000u   /* reset status change         */

/* Writes to HcRhPortStatus set/clear by bit position rather than by value. */
#define PORT_W_CCS_CLEAR_ENABLE 0x00000001u   /* ClearPortEnable             */
#define PORT_W_PES_SET_ENABLE   0x00000002u   /* SetPortEnable               */
#define PORT_W_PRS_SET_RESET    0x00000010u   /* SetPortReset                */
#define PORT_W_PPS_SET_POWER    0x00000100u   /* SetPortPower                */
#define PORT_W_CLEAR_POWER      0x00000200u   /* ClearPortPower              */

/* The MCPX gives each controller a small root hub. Two ports apiece covers
 * the console's four front sockets, which is what a title enumerates over. */
#define OHCI_PORTS              2

/* Passes this thread will keep an interrupt back while the guest is at
 * DISPATCH_LEVEL or above. One pass is the OHCI_TICK_MS (4 ms) loop tick, so
 * this is two seconds.
 *
 * It was 80 ms, on the reasoning that no real critical section lasts longer.
 * True of the hardware and false here: recompiled code under an emulated
 * kernel is slower than the console by a wide and variable margin, and the
 * section XAPI holds while it opens the gamepad's interrupt pipe overran it.
 * The interrupt then landed in the middle of that setup and the title faulted
 * on a half-built structure. Two seconds is still not forever -- a guest that
 * genuinely never lowers is still not allowed to switch the device off -- but
 * it is long enough that a slow critical section is not mistaken for one. */
#define OHCI_IRQ_HOLDOFF        500

/* Milliseconds per pass of the controller thread, which is also how many USB
 * frames a pass is worth.
 *
 * It was 20. A control transfer needs a pass per stage and enumeration needs
 * several transfers, so twenty milliseconds put the whole sequence in the
 * hundreds of milliseconds and left it racing the driver's own timeouts: the
 * same build would enumerate fully on one run and stop half way on the next,
 * with nothing to tell the two apart but how many register reads happened.
 * Four is close enough to a real frame to stop losing that race and still
 * cheap -- this thread does nothing but read a few guest dwords per pass. */
#define OHCI_TICK_MS            4u

typedef struct {
    uint32_t base;                      /* Xbox VA of the register block   */
    uint32_t reg[OHCI_REG_MAX / 4];
    unsigned reads, writes, decode_fail;
    int      index;
    int      periodic_seen;
    int      ple_seen;
    /* Bumped every time the driver writes HcInterruptStatus. The interrupt
     * thread watches it to tell a source nobody is servicing from one that
     * is simply busy -- see the delivery loop. */
    volatile unsigned ack_seq;
} OhciController;

static OhciController s_hc[2];
/* Which controller carries the device, and so which one this thread services.
 * XAPI numbers its four gamepad slots across both controllers, and which end
 * it starts from decides whether a pad shows up as player 1 or player 3 --
 * a mapping worth finding by measurement, not by assertion. */
static int s_device_hc;
/* Downstream ports the root hub reports in HcRhDescriptorA. Two is what the
 * MCPX's own hubs have; RECOMP_USB_NDP exists because which slot XAPI gives a
 * pad is decided somewhere in here and the mapping is worth measuring. */
static unsigned s_ndp = OHCI_PORTS;
static void ohci_dev_reset(unsigned port);   /* a bus reset on that port */
static int s_enabled;
static int s_trace;

static uint32_t *reg_of(OhciController *hc, uint32_t off)
{
    return (off < OHCI_REG_MAX) ? &hc->reg[off / 4] : NULL;
}

/* ---- register semantics ------------------------------------------------ */

static uint64_t ohci_read(void *dev, uint32_t off, int size)
{
    OhciController *hc = (OhciController *)dev;
    uint32_t aligned = off & ~3u;
    uint32_t *r = reg_of(hc, aligned);
    uint32_t v = r ? *r : 0;

    hc->reads++;

    /* HcFmRemaining and HcFmNumber advance on their own. A driver that waits
     * for the frame counter to move is waiting for the controller to be
     * running, and a counter that never changes is a controller that is not.
     * Derived from the read count rather than a timer: it only has to be
     * monotonic, and a timer here would need a thread to be worth having. */
    if (aligned == HcFmNumber)
        v = (hc->reads >> 3) & 0xFFFFu;
    else if (aligned == HcFmRemaining)
        v = (hc->reads * 977u) & 0x3FFFu;

    /* Sub-dword reads take their slice of the containing register. */
    if (size < 4) {
        unsigned shift = (off & 3u) * 8u;
        v >>= shift;
        if (size == 1) v &= 0xFFu;
        else if (size == 2) v &= 0xFFFFu;
    }

    if (s_trace) {
        static unsigned n;
        if (n++ < 600)
            fprintf(stderr, "  [OHCI%d] read  +0x%02X = %08X\n",
                    hc->index, off, (uint32_t)v);
    }
    return v;
}

static void ohci_write(void *dev, uint32_t off, uint64_t val, int size)
{
    OhciController *hc = (OhciController *)dev;
    uint32_t aligned = off & ~3u;
    uint32_t *r = reg_of(hc, aligned);
    uint32_t v = (uint32_t)val;

    hc->writes++;
    if (!r)
        return;

    if (s_trace) {
        static unsigned n;
        if (n++ < 600)
            fprintf(stderr, "  [OHCI%d] write +0x%02X = %08X\n",
                    hc->index, off, v);
    }

    switch (aligned) {
    case HcRevision:                    /* read-only */
        return;

    case HcCommandStatus:
        /* HCR is self-clearing: the controller resets and drops the bit, and
         * a driver polls for exactly that. Leaving it set is a hang, and it
         * is the first thing a driver does, so it would be the only thing
         * anyone ever saw of this file. */
        *r |= v;
        if (*r & CS_HCR) {
            *r &= ~CS_HCR;
            hc->reg[HcControl / 4] &= ~0xC0u;    /* back to UsbReset state  */
            hc->reg[HcInterruptStatus / 4] = 0;
            hc->reg[HcInterruptEnable / 4] = 0;
        }
        return;

    case HcInterruptStatus:
        /* Acknowledging WritebackDoneHead retires the done list.
         *
         * The controller publishes the queue in HccaDoneHead and raises WDH;
         * the driver reads the list and clears WDH to say it is finished, and
         * the head must then read as zero. Leaving the old value there is a
         * stale pointer to descriptors that have already been consumed, and a
         * driver that checks the head before trusting the interrupt walks
         * them a second time. That is a plausible way to enumerate a device
         * perfectly and then stop, which is what happened here. */
        if ((v & INTR_WDH) && (*r & INTR_WDH)) {
            uint32_t hcca = hc->reg[HcHCCA / 4];
            if (hcca)
                wr32(hcca + HCCA_DONE_HEAD, 0);
            /* HcDoneHead is NOT cleared: it may hold TDs retired while the
             * driver was busy, which ohci_flush_done publishes next frame. */
        }
        *r &= ~v;                       /* write 1 to clear                 */
        hc->ack_seq++;
        return;

    case HcInterruptEnable:
        hc->reg[HcInterruptEnable / 4] |= v;
        return;

    case HcInterruptDisable:
        hc->reg[HcInterruptEnable / 4] &= ~v;
        return;

    case HcFmNumber:
    case HcFmRemaining:
        return;                         /* driven by the controller         */

    case HcRhDescriptorA:
        /* NumberDownstreamPorts is ours; the driver may set the power and
         * over-current policy bits above it. */
        *r = (*r & 0x000000FFu) | (v & ~0x000000FFu);
        return;

    case HcRhPortStatus1:
    case HcRhPortStatus1 + 4:
    case HcRhPortStatus1 + 8:
    case HcRhPortStatus1 + 12: {
        /* Writes here are set/clear requests by bit position, not a value to
         * store. Getting that wrong looks like a port that will not enable.
         *
         * All four, not the two this root hub usually advertises. The read
         * path already answers four, because a driver reads every port
         * register whatever the descriptor says; the write path did not, so a
         * device placed on port 3 was seen, reset, and never reset-completed
         * -- the request fell through to the plain store and PRSC was never
         * raised. The driver reset it forever. A hub that reports N ports has
         * to give all N the same semantics. */
        unsigned port = (aligned - HcRhPortStatus1) / 4;
        uint32_t *ps = &hc->reg[(HcRhPortStatus1 + port * 4) / 4];

        /* Write-1-to-clear first, because the change bits a write carries
         * refer to the state BEFORE it.
         *
         * This ordering is the whole bug it once had. A driver starting a
         * fresh reset writes SetPortReset and ClearPortResetStatusChange in
         * the same word -- "acknowledge the last reset, begin another" --
         * which is both legal and what the Xbox USB stack does: DDS9 writes
         * 0x01100010. Clearing afterwards wiped the PRSC this very write had
         * just raised, so the reset never reported complete, the driver
         * reset the port again, and enumeration looped forever one step from
         * finishing. The port looked healthy the whole time: connected,
         * enabled, powered. */
        *ps &= ~(v & 0xFFFF0000u);

        if (v & PORT_W_CCS_CLEAR_ENABLE) *ps &= ~PORT_PES;
        if (v & PORT_W_PES_SET_ENABLE)   *ps |= (*ps & PORT_CCS) ? PORT_PES : 0;
        if (v & PORT_W_PPS_SET_POWER)    *ps |= PORT_PPS;
        if (v & PORT_W_CLEAR_POWER)      *ps &= ~PORT_PPS;
        if (v & PORT_W_PRS_SET_RESET) {
            /* Reset completes immediately -- there is no wire to settle -- so
             * PRS is never observed set. What matters is what the driver
             * checks afterwards: a present device comes back enabled, and the
             * reset-change bit says the reset finished.
             *
             * Only the status bit is set here. Delivering the interrupt is the
             * controller thread's job, because this runs on the guest's own
             * thread inside a fault handler, and pointing g_esp at a worker
             * stack from here would overwrite the stack pointer of the thread
             * being interrupted. */
            if (*ps & PORT_CCS)
                *ps |= PORT_PES;
            *ps |= PORT_PRSC;
            if (hc->index == s_device_hc)
                ohci_dev_reset(port);
            hc->reg[HcInterruptStatus / 4] |= INTR_RHSC;
        }
        return;
    }

    default:
        break;
    }

    if (size == 4) {
        *r = v;
    } else {
        unsigned shift = (off & 3u) * 8u;
        uint32_t mask = ((size == 1) ? 0xFFu : 0xFFFFu) << shift;
        *r = (*r & ~mask) | ((v << shift) & mask);
    }
}

/* ---- the control list -------------------------------------------------- */
/*
 * A host controller is a bus master: the driver builds endpoint and transfer
 * descriptors in RAM, points HcControlHeadED at them and sets ControlListFilled,
 * and the controller walks that list itself. Nothing arrives through MMIO, so
 * none of this is visible to the register trace -- which is why the driver
 * looked idle after the port came up.
 *
 * OHCI 1.0a, section 4. An endpoint descriptor is four dwords:
 *
 *   +0  FA | EN<<7 | D<<11 | S<<13 | K<<14 | F<<15 | MPS<<16
 *   +4  TailP        queue tail, 16-byte aligned
 *   +8  HeadP        queue head, with Halted in bit 0 and toggleCarry in bit 1
 *   +C  NextED
 *
 * and a general transfer descriptor is four more:
 *
 *   +0  ... DP<<19 | DI<<21 | T<<24 | EC<<26 | CC<<28
 *   +4  CBP          current buffer pointer, 0 when the transfer moved nothing
 *   +8  NextTD
 *   +C  BE           last byte of the buffer, inclusive
 *
 * A transfer is done when HeadP reaches TailP. Completed descriptors go on the
 * done queue, newest first, and the controller publishes it in the HCCA and
 * raises WritebackDoneHead.
 */
#define ED_SKIP        (1u << 14)
#define ED_HEAD_HALT   (1u << 0)
#define ED_HEAD_TOGGLE (1u << 1)
#define ED_PTR_MASK    0xFFFFFFF0u

#define TD_DP_SETUP    0u
#define TD_DP_OUT      1u
#define TD_DP_IN       2u
#define TD_CC_NOERROR  0u
#define TD_CC_STALL    4u
#define TD_CC_NOTRESPONDING 5u
#define TD_CC_DATAUNDERRUN 9u
#define TD_ROUNDING    (1u << 18)   /* bufferRounding: a short packet is fine */



/* The control transfer's data stage, across however many descriptors it takes.
 *
 * bMaxPacketSize0 is 8, so a driver asking for a 32-byte configuration
 * descriptor queues four 8-byte IN descriptors and expects successive chunks.
 * Answering each one from the top of the buffer hands it the first 8 bytes
 * four times: the descriptor it assembles is nonsense, it gives up and starts
 * again, which is exactly the loop DDS9 sat in -- GET_DESCRIPTOR, SET_ADDRESS,
 * GET_DESCRIPTOR, forever. The answer is computed once per setup packet and
 * then consumed. */
typedef struct {
    UsbSetup setup;
    uint32_t pending;               /* a SETUP is waiting for its stages */
    uint8_t  buf[64];
    int      len;                   /* -1 = not answered yet */
    int      sent;
} UsbCtrl;

/* One per pad: each has its own default pipe. */
static UsbCtrl s_ctrl[USB_GAMEPADS];

/* The pads, each on its own root hub port of s_device_hc. Pad 0 is plugged
 * once the driver is listening; the others as their host pad comes and goes
 * (usb_gamepad_connected). XAPI numbers players by port. */
static unsigned s_ndev = 1;
static unsigned s_dev_port[USB_GAMEPADS];
static int      s_dev_plugged[USB_GAMEPADS];
static unsigned s_reset_seq[USB_GAMEPADS];   /* last port reset, for FA 0 */
static unsigned s_reset_clock;

/* Every address below came out of guest memory, so none of them are trusted.
 *
 * This is not theoretical. The driver writes HcControlHeadED twice during
 * bring-up, and the second write is 0xCCCCCCCC -- MSVC's uninitialised-memory
 * fill, left there by a local that was never assigned. Following it lands far
 * outside the mapping and takes the runtime down with an access violation,
 * which is a crash the title itself would never have had. A device model
 * following a pointer a title left lying around has to check it first.
 */
/* The contiguous (physical-mirror) window. Mapped separately from main RAM
 * and far above it, so a size check against the mapped RAM size rejects it. */
#define OHCI_CONTIG_BASE 0x80000000u
#define OHCI_CONTIG_SIZE (64u * 1024u * 1024u)

static int guest_ok(uint32_t va, uint32_t bytes)
{
    size_t mapped = xbox_GetMappedSize();

    if (va == 0 || mapped == 0)
        return 0;
    /* Descriptors live where a driver puts DMA memory, and on Xbox that is
     * MmAllocateContiguousMemory -- the contiguous window, not low RAM. The
     * bound below reads as "is this in RAM", which is not the question: the
     * window is mapped too, at the same offset, and is exactly where the Xbox
     * USB stack builds its endpoint and transfer descriptors. Rejecting it
     * made every rd32 return 0 and every wr32 a no-op, so the walker looked at
     * an empty list and the driver waited forever for a done queue that could
     * not be written. DDS9's first control transfer sits at 0x80408940. */
    if (va >= OHCI_CONTIG_BASE
            && (uint64_t)va + bytes <= (uint64_t)OHCI_CONTIG_BASE
                                     + OHCI_CONTIG_SIZE)
        return 1;
    return (uint64_t)va + bytes <= (uint64_t)mapped;
}

/* Every address a USB driver gives the controller -- HcHCCA, HcControlHeadED,
 * ED/TD links, buffer pointers -- is a bus (physical) address, obtained with
 * MmGetPhysicalAddress. For MmAllocateContiguousMemory memory that now returns
 * the physical offset (VA - 0x80000000), not the VA: DDS9's 0x80408940 above
 * dates from when it returned the VA unchanged. Used as a VA, a physical offset
 * lands in low RAM -- on X-Men Legends inside the title's own .data -- so the
 * walker saw an empty ED list (enumeration never happened) and every frame
 * wrote HccaFrameNumber/DoneHead into the game's globals.
 *
 * The same rule the pushbuffer executor uses (dma_resolve): an address inside
 * the contiguous arena is contiguous memory, reached through the window;
 * anything else (a pass-through VA, e.g. a static .data buffer) is used as-is.
 * The arena starts above the image so the two cannot collide. */
extern int xbox_ContiguousIsPhysical(uint32_t phys);

static uint32_t bus_to_va(uint32_t bus)
{
    if (bus & XBOX_BUS_RAM_TAG)                 /* ordinary RAM: kernel.h */
        return bus & ~XBOX_BUS_RAM_TAG;
    if (bus && xbox_ContiguousIsPhysical(bus))
        return OHCI_CONTIG_BASE + bus;
    /* Below the XBE base (0x10000) nothing is RAM a driver could DMA into as
     * a VA -- page zero and the fake TIB live there -- so such a bus address
     * can only be physical: contiguous memory allocated before the arena
     * moved above the image, like the first page of the window XAPI uses.
     * NFSU2's pad report buffer is there (physical 0x2BB); read as a VA,
     * every interrupt-IN report went to page zero and no button was ever
     * seen. */
    if (bus && bus < 0x10000u)
        return OHCI_CONTIG_BASE + bus;
    return bus;
}

static uint32_t rd32(uint32_t bus)
{
    uint32_t va = bus_to_va(bus);
    if (!guest_ok(va, 4))
        return 0;
    return *(uint32_t *)((uint8_t *)xbox_GetMemoryOffset() + va);
}
static void wr32(uint32_t bus, uint32_t v)
{
    uint32_t va = bus_to_va(bus);
    if (!guest_ok(va, 4))
        return;
    *(uint32_t *)((uint8_t *)xbox_GetMemoryOffset() + va) = v;
}
static uint8_t *guest_ptr(uint32_t bus, uint32_t bytes)
{
    uint32_t va = bus_to_va(bus);
    return guest_ok(va, bytes)
         ? (uint8_t *)xbox_GetMemoryOffset() + va : NULL;
}

/* Move one transfer descriptor. Returns the condition code to report. */
/* A bus reset puts the device on that port back at address 0. */
static void ohci_dev_reset(unsigned port)
{
    unsigned d;

    for (d = 0; d < s_ndev; d++)
        if (s_dev_port[d] == port) {
            usb_gamepad_reset((int)d);
            memset(&s_ctrl[d], 0, sizeof s_ctrl[d]);
            s_ctrl[d].len = -1;
            s_reset_seq[d] = ++s_reset_clock;
        }
}

/* The pad a transfer is for, by the endpoint's function address: the one
 * on an enabled port that SET_ADDRESS gave that address. Address 0 is the
 * pad that was reset last and not addressed yet -- the driver enumerates one
 * port at a time. -1 if none. */
static int dev_for_address(OhciController *hc, uint32_t fa)
{
    int best = -1;
    unsigned d;

    if (hc->index != s_device_hc)
        return -1;
    for (d = 0; d < s_ndev; d++) {
        uint32_t ps = hc->reg[(HcRhPortStatus1 + s_dev_port[d] * 4) / 4];
        if (!s_dev_plugged[d] || !(ps & PORT_PES)
                || usb_gamepad_address((int)d) != fa)
            continue;
        if (best < 0 || s_reset_seq[d] > s_reset_seq[best])
            best = (int)d;
    }
    return best;
}

static uint32_t ohci_do_td(OhciController *hc, uint32_t ed0, uint32_t td)
{
    uint32_t info = rd32(td);
    uint32_t cbp  = rd32(td + 4);
    uint32_t be   = rd32(td + 12);
    uint32_t dp   = (info >> 19) & 3u;
    int      len  = (cbp && be >= cbp) ? (int)(be - cbp + 1) : 0;
    uint32_t endpoint = (ed0 >> 7) & 0xFu;
    int      moved = 0;
    int      dev = dev_for_address(hc, ed0 & 0x7Fu);
    UsbCtrl *c;

    /* Nobody at that address: no handshake, which the driver reads as an
     * empty or unplugged port. */
    if (dev < 0)
        return TD_CC_NOTRESPONDING;
    c = &s_ctrl[dev];

    if (s_trace) {
        static unsigned n;
        if (n++ < 80) {
            fprintf(stderr, "  [OHCI%d] TD %08X dp=%u ep=%u cbp=%08X be=%08X "
                            "len=%d\n", hc->index, td, dp, endpoint, cbp, be,
                    len);
            fflush(stderr);
        }
    }
    if (dp == TD_DP_SETUP) {
        /* Eight bytes of setup, kept for the data stage that follows. */
        if (len >= 8) {
            const uint8_t *p = guest_ptr(cbp, 8);
            if (!p) return TD_CC_NOERROR;
            c->setup.bmRequestType = p[0];
            c->setup.bRequest      = p[1];
            c->setup.wValue        = (uint16_t)(p[2] | (p[3] << 8));
            c->setup.wIndex        = (uint16_t)(p[4] | (p[5] << 8));
            c->setup.wLength       = (uint16_t)(p[6] | (p[7] << 8));
            c->pending = 1;
            c->len = -1;   /* answered lazily on the first IN */
            c->sent = 0;
            if (s_trace) {
                fprintf(stderr, "  [OHCI%d] SETUP %02X %02X value %04X "
                                "index %04X len %u\n",
                        hc->index, c->setup.bmRequestType, c->setup.bRequest,
                        c->setup.wValue, c->setup.wIndex, c->setup.wLength);
                fflush(stderr);
            }
            moved = 8;
        }
    } else if (dp == TD_DP_IN) {
        if (endpoint == 0) {
            /* Data stage of a control transfer, or its status stage when the
             * driver asks for nothing. */
            int n;

            if (!c->pending)
                return TD_CC_NOERROR;
            if (c->len < 0) {
                c->len = usb_gamepad_control(dev, &c->setup, c->buf,
                                                 (int)sizeof c->buf);
                if (c->len < 0) {
                    /* Worth saying out loud. A stall here halts the
                     * endpoint until the driver clears it, and a driver
                     * that sees one usually stops using the device -- so
                     * an unhandled request is not a gap that degrades
                     * gracefully, it is one that ends input. */
                    fprintf(stderr, "  [OHCI%d] STALL: unhandled control "
                            "request %02X %02X value %04X index %04X len %u\n",
                            hc->index, c->setup.bmRequestType, c->setup.bRequest,
                            c->setup.wValue, c->setup.wIndex, c->setup.wLength);
                    fflush(stderr);
                    c->pending = 0;
                    return TD_CC_STALL;
                }
                c->sent = 0;
            }
            /* Whatever is left, capped by this descriptor's buffer. A short
             * packet is how the device says "that is all", so running out is
             * the normal end of the stage rather than an error. */
            n = c->len - c->sent;
            if (n > len) n = len;
            if (n < 0) n = 0;
            if (n > 0 && guest_ptr(cbp, (uint32_t)n))
                memcpy(guest_ptr(cbp, (uint32_t)n),
                       c->buf + c->sent, (size_t)n);
            c->sent += n;
            moved = n;
            if (s_trace && n > 0) {
                fprintf(stderr, "  [OHCI%d] IN ep0 %d bytes (%d/%d)\n",
                        hc->index, n, c->sent, c->len);
                fflush(stderr);
            }
        } else {
            /* The pad's report, on its interrupt endpoint. */
            static int polled[USB_GAMEPADS];
            uint8_t rep[32];
            int n = usb_gamepad_report(dev, rep, (int)sizeof rep);
            if (!polled[dev]) {
                polled[dev] = 1;
                fprintf(stderr, "  [OHCI%d] pad %d (address %u, port %u) "
                        "polled\n", hc->index, dev + 1,
                        usb_gamepad_address(dev), s_dev_port[dev] + 1);
                fflush(stderr);
            }
            if (n > len) n = len;
            if (n > 0 && guest_ptr(cbp, (uint32_t)n))
                memcpy(guest_ptr(cbp, (uint32_t)n), rep, (size_t)n);
            moved = n;
        }
    } else {
        /* OUT: the status stage of an IN control transfer, the data stage
         * of a SET_REPORT, or the rumble report on interrupt endpoint 2. */
        const uint8_t *p = (len > 0) ? guest_ptr(cbp, (uint32_t)len) : NULL;

        if (p && (endpoint != 0
                  || (c->pending && !(c->setup.bmRequestType & 0x80u)
                      && (c->setup.bmRequestType & 0x60u) == 0x20u
                      && c->setup.bRequest == 0x09u)))
            usb_gamepad_output(dev, p, len);
        moved = len;
        if (endpoint == 0)
            c->pending = 0;
    }

    /* CBP is zero when everything asked for moved, and otherwise points past
     * what did. A driver computes the transferred length from it. */
    wr32(td + 4, (moved >= len) ? 0u : cbp + (uint32_t)moved);

    /* A short IN packet on a TD without bufferRounding is DATA UNDERRUN: the
     * controller retires this TD with that code and halts the endpoint (the
     * walker does so for any non-zero code), leaving the rest of the transfer
     * for the driver to retire. Reporting NOERROR instead -- and completing
     * the trailing TDs with zero bytes -- sent XAPI's done-queue handler down
     * its success path, which walks from the ED head into the dummy tail TD
     * and follows its garbage link: X-Men Legends asks for 80 bytes of
     * configuration descriptor, gets 32, and faulted there. */
    if (dp == TD_DP_IN && moved < len && !(info & TD_ROUNDING))
        return TD_CC_DATAUNDERRUN;
    return TD_CC_NOERROR;
}

/* Walk the control list once. Returns 1 if anything completed. */
/* Walk one list of endpoint descriptors, moving whatever is queued on each.
 *
 * Shared, because the control list is not the only one that matters: a gamepad
 * delivers its reports on an interrupt endpoint, and those EDs hang off the
 * HCCA interrupt table rather than HcControlHeadED. Walking only the control
 * list enumerates a device perfectly and then never hears from it again. */
static int ohci_walk_eds(OhciController *hc, uint32_t ed, uint32_t *done_head)
{
    int completed = 0, guard = 0;

    while (guest_ok(ed, 16) && ++guard < 64) {
        uint32_t ed0  = rd32(ed);
        uint32_t tail = rd32(ed + 4) & ED_PTR_MASK;
        uint32_t head = rd32(ed + 8);
        int tguard = 0;

        if (s_trace) {
            static unsigned n;
            if (n++ < 60) {
                fprintf(stderr, "  [OHCI%d] ED %08X info=%08X head=%08X "
                                "tail=%08X next=%08X\n", hc->index, ed, ed0,
                        head, tail, rd32(ed + 12));
                fflush(stderr);
            }
        }
        if (ed0 & ED_SKIP) { ed = rd32(ed + 12) & ED_PTR_MASK; continue; }
        if (head & ED_HEAD_HALT) { ed = rd32(ed + 12) & ED_PTR_MASK; continue; }

        while ((head & ED_PTR_MASK) != tail
            && guest_ok(head & ED_PTR_MASK, 16) && ++tguard < 64) {
            uint32_t td = head & ED_PTR_MASK;
            uint32_t next = rd32(td + 8) & ED_PTR_MASK;
            uint32_t cc = ohci_do_td(hc, ed0, td);

            /* A non-zero completion code is what sends a driver down its
             * error path; always worth a line, trace or not. */
            if (cc != TD_CC_NOERROR) {
                static unsigned shown;
                if (shown++ < 32) {
                    uint32_t t = next, k;
                    fprintf(stderr, "  [OHCI%d] TD %08X ep %u -> cc %u (ED %08X info %08X,"
                                    " TD info %08X, next %08X, ED tail %08X)"
                                    " own | %08X %08X %08X %08X\n",
                            hc->index, td, (ed0 >> 7) & 0xFu, cc, ed, ed0,
                            rd32(td), next, tail,
                            rd32(td + 16), rd32(td + 20), rd32(td + 24), rd32(td + 28));
                    /* The rest of the transfer, as the driver will walk it:
                     * hardware words, then its own +0x10..+0x1F fields. */
                    for (k = 0; k < 10 && t && t != tail; k++) {
                        fprintf(stderr, "    TD %08X info %08X cbp %08X next %08X be %08X"
                                        " | %08X %08X %08X %08X\n",
                                t, rd32(t), rd32(t + 4), rd32(t + 8), rd32(t + 12),
                                rd32(t + 16), rd32(t + 20), rd32(t + 24), rd32(t + 28));
                        t = rd32(t + 8) & ED_PTR_MASK;
                    }
                    fprintf(stderr, "    tail TD %08X info %08X next %08X | %08X %08X %08X %08X\n",
                            tail, rd32(tail), rd32(tail + 8), rd32(tail + 16),
                            rd32(tail + 20), rd32(tail + 24), rd32(tail + 28));
                    fflush(stderr);
                }
            }

            /* Report the outcome where the driver reads it, then put the
             * descriptor on the done queue, newest first. */
            wr32(td, (rd32(td) & 0x0FFFFFFFu) | (cc << 28));
            wr32(td + 8, *done_head);
            *done_head = td;
            completed++;

            head = next | (head & ED_HEAD_TOGGLE);
            if (cc != TD_CC_NOERROR) {
                head |= ED_HEAD_HALT;       /* a stall halts the endpoint */
                break;
            }
        }
        wr32(ed + 8, head);
        ed = rd32(ed + 12) & ED_PTR_MASK;
    }

    return completed;
}

/* Write the held done queue to HccaDoneHead, if the driver is ready for it.
 *
 * OHCI 1.0a 6.4.4 / 7.1.4: the controller keeps retired TDs in HcDoneHead and
 * writes them to HccaDoneHead only while WritebackDoneHead is clear; after
 * writing it sets WDH and clears HcDoneHead. While WDH is set the HCCA list
 * belongs to the driver. Overwriting it whenever something completed replaced
 * lists the driver was still walking, and XAPI then processed (and freed) the
 * same TDs twice: X-Men Legends faulted on a freed TD's free-list link read
 * back as its ED pointer. */
static void ohci_flush_done(OhciController *hc)
{
    uint32_t hcca = hc->reg[HcHCCA / 4];
    uint32_t held = hc->reg[HcDoneHead / 4];

    if (!held || (hc->reg[HcInterruptStatus / 4] & INTR_WDH))
        return;
    if (hcca)
        wr32(hcca + HCCA_DONE_HEAD, held);
    if (s_trace) {
        static unsigned n;
        uint32_t t = held, k;
        if (n++ < 40) {
            fprintf(stderr, "  [OHCI%d] done list:", hc->index);
            for (k = 0; t && k < 12; k++) {
                fprintf(stderr, " %08X", t);
                t = rd32(t + 8) & ED_PTR_MASK;
            }
            fprintf(stderr, "%s\n", t ? " ..." : " (end)");
            fflush(stderr);
        }
    }
    hc->reg[HcDoneHead / 4] = 0;
    hc->reg[HcInterruptStatus / 4] |= INTR_WDH;
}

/* Retire a freshly completed list: chain it in front of anything already
 * held (newest first, as hardware orders the done queue), then publish if
 * the driver has acknowledged the previous list. */
static void ohci_publish_done(OhciController *hc, uint32_t done_head)
{
    uint32_t held = hc->reg[HcDoneHead / 4];

    if (held) {
        uint32_t t = done_head, guard = 0, nxt;
        while (t && ++guard < 256 && (nxt = rd32(t + 8) & ED_PTR_MASK) != 0)
            t = nxt;
        if (t)
            wr32(t + 8, held);
    }
    hc->reg[HcDoneHead / 4] = done_head;
    ohci_flush_done(hc);
}

static int ohci_run_control_list(OhciController *hc)
{
    uint32_t done_head = 0;
    int completed = ohci_walk_eds(hc,
            hc->reg[HcControlHeadED / 4] & ED_PTR_MASK, &done_head);

    if (completed)
        ohci_publish_done(hc, done_head);
    return completed;
}

/* The periodic list for the current frame.
 *
 * The HCCA opens with 32 ED pointers, one per frame slot, and the controller
 * services the one the frame number selects. An interrupt endpoint polled
 * every 4 ms appears in several slots, so cycling through them the way the
 * frame counter does is what makes its transfers happen at all. */
static int ohci_run_periodic_list(OhciController *hc)
{
    uint32_t hcca = hc->reg[HcHCCA / 4];
    uint32_t done_head = 0;
    uint32_t slot, ed;
    int completed;

    if (!hcca)
        return 0;
    /* Every slot, not the one the frame counter happens to land on.
     *
     * A tick covers twenty frames, and stepping the counter by twenty means
     * only slots that are multiples of four are ever selected -- gcd(20,32)
     * is 4, so twenty-four of the thirty-two are never looked at. An
     * interrupt endpoint that lands in one of those is polled by the driver
     * and serviced by nobody. Sweeping all of them costs a guest read per
     * slot and cannot miss. */
    completed = 0;
    for (slot = 0; slot < 32u; slot++) {
        ed = rd32(hcca + slot * 4u) & ED_PTR_MASK;
        if (!ed)
            continue;
        /* The first interrupt endpoint the driver publishes is the one the
         * input reports ride on, so say so once: an enumerated pad whose
         * table stays empty is a pad nobody opened, which is a different
         * problem from a pad nobody serviced. */
        if (!hc->periodic_seen) {
            hc->periodic_seen = 1;
            fprintf(stderr, "  [OHCI%d] periodic slot %u -> ED %08X "
                    "info=%08X\n", hc->index, slot, ed, rd32(ed));
            fflush(stderr);
        }
        completed += ohci_walk_eds(hc, ed, &done_head);
    }
    if (completed)
        ohci_publish_done(hc, done_head);
    return completed;
}

/* ---- raising an interrupt --------------------------------------------- */

/* Call the title's ISR on this thread, with a guest stack under it.
 *
 * BOOLEAN ServiceRoutine(PKINTERRUPT Interrupt, PVOID ServiceContext), stdcall,
 * so the two arguments go on the stack right to left with a return address on
 * top. The sentinel is what the routine pops on the way out; nothing jumps to
 * it, and a recognisable value beats a real address if it ever shows up in a
 * report.
 *
 * Returns what the routine returned: an ISR that does not claim the interrupt
 * returns FALSE, and that is worth seeing rather than assuming.
 */
static int ohci_call_isr(OhciController *hc)
{
    uint32_t kinterrupt = xbox_GetConnectedInterrupt(OHCI_VECTOR);
    uint32_t routine, context;
    recomp_func_t fn;
    uint8_t *mem;
    int slot;

    if (!kinterrupt)
        return -1;                      /* nothing connected yet            */

    mem     = (uint8_t *)xbox_GetMemoryOffset();
    routine = *(uint32_t *)(mem + kinterrupt + 0);
    context = *(uint32_t *)(mem + kinterrupt + 4);
    if (!routine)
        return -1;

    /* A context whose first dword is not a controller base is what the
     * driver's ISR faults on; say what changed, once per change. */
    {
        static uint32_t last_ctx, last_first;
        uint32_t first = context ? *(uint32_t *)(mem + context) : 0;
        if (context != last_ctx || first != last_first) {
            fprintf(stderr, "  [OHCI%d] ISR 0x%08X kinterrupt 0x%08X context 0x%08X"
                            " [context]=0x%08X\n",
                    hc->index, routine, kinterrupt, context, first);
            fflush(stderr);
            last_ctx = context;
            last_first = first;
        }
    }

    fn = recomp_lookup(routine);
    if (!fn) {
        fprintf(stderr, "  [OHCI%d] ISR 0x%08X has no translation\n",
                hc->index, routine);
        fflush(stderr);
        return -1;
    }

    /* One slice for the life of the raise. Sixteen exist and this takes one
     * only while the routine runs, so a title using them for its own workers
     * is not starved by a controller that interrupts. */
    slot = xbox_worker_stack_alloc();
    if (slot < 0) {
        fprintf(stderr, "  [OHCI%d] no worker stack for the ISR\n", hc->index);
        fflush(stderr);
        return -1;
    }

    g_esp = XBOX_WORKER_STACK_TOP(slot);
    {
        static int last_slot = -1;
        if (slot != last_slot) {
            fprintf(stderr, "  [OHCI%d] ISR on worker stack slice %d (top 0x%08X)\n",
                    hc->index, slot, g_esp);
            fflush(stderr);
            last_slot = slot;
        }
    }
    g_eax = g_ecx = g_edx = g_ebx = g_esi = g_edi = 0;

    g_esp -= 4; *(uint32_t *)(mem + g_esp) = context;      /* arg 2 */
    g_esp -= 4; *(uint32_t *)(mem + g_esp) = kinterrupt;   /* arg 1 */
    g_esp -= 4; *(uint32_t *)(mem + g_esp) = 0xDEADBEEFu;  /* return address */

    xbox_gil_isr_begin();          /* the ISR is guest code: one CPU, run to completion */
    fn();
    xbox_gil_isr_end();

    xbox_worker_stack_free(slot);
    return (int)(g_eax & 1u);
}

/* Set the status bits and, if the driver has unmasked them, call the ISR.
 *
 * MIE is the master enable and HcInterruptEnable is the per-source mask; a
 * controller that interrupts through either of those while they are clear is
 * a controller the driver has every right to be confused by.
 */
static void ohci_raise(OhciController *hc, uint32_t source)
{
    uint32_t enable = hc->reg[HcInterruptEnable / 4];
    int claimed;

    hc->reg[HcInterruptStatus / 4] |= source;

    if (!(enable & INTR_MIE) || !(enable & source))
        return;

    claimed = ohci_call_isr(hc);
    if (s_trace || claimed >= 0) {
        static unsigned n;
        if (n++ < 20) {
            fprintf(stderr, "  [OHCI%d] raised %08X -> ISR %s\n",
                    hc->index, source,
                    claimed < 0 ? "not callable" :
                    claimed ? "claimed it" : "declined it");
            fflush(stderr);
        }
    }
}

/* ---- bring-up ---------------------------------------------------------- */

static void ohci_reset(OhciController *hc, uint32_t base, int index)
{
    memset(hc, 0, sizeof *hc);
    hc->base  = base;
    hc->index = index;

    hc->reg[HcRevision / 4]       = 0x00000010u;   /* OHCI 1.0             */
    hc->reg[HcFmInterval / 4]     = 0x27782EDFu;   /* 11999, FSMPS default */
    hc->reg[HcPeriodicStart / 4]  = 0x00003E67u;   /* 90% of the frame     */
    hc->reg[HcLSThreshold / 4]    = 0x00000628u;

    /* Root hub: OHCI_PORTS downstream, ports always powered, no over-current
     * reporting. NoPowerSwitching keeps a driver from waiting on a power-on
     * sequence that has nothing to switch. */
    hc->reg[HcRhDescriptorA / 4]  = (uint32_t)s_ndp | (1u << 9);
    hc->reg[HcRhDescriptorB / 4]  = 0x00000000u;
    hc->reg[HcRhStatus / 4]       = 0x00000000u;

    /* Ports powered and empty. The gamepad is not here yet, deliberately.
     *
     * Presenting it as already connected does not work, and the reason is
     * worth keeping: the driver scans the root hub itself during bring-up,
     * sees the connect-status-change bit, clears it, and by the time it
     * unmasks the root hub interrupt there is no change left to report. The
     * pending status bit does not survive either, because the driver resets
     * the controller first and a reset clears interrupt status -- both of
     * those are correct behaviour, and between them a device that was always
     * there is a device that never arrives.
     *
     * A console detects the port change after the controller is running, so
     * that is what the controller thread does: it waits for operational with
     * the interrupt unmasked, and only then plugs the device in. */
    /* Every port the descriptor claims, not the first two.
     *
     * A root hub that reports four downstream ports and powers two has two
     * ports a driver will skip: no PortPowerStatus is an unpowered socket,
     * and nothing is expected to arrive on one. That made a device placed on
     * port 3 invisible, which read as "the driver only scans two ports" and
     * is really "we only powered two". */
    {
        unsigned p;
        for (p = 0; p < 4u; p++)
            hc->reg[(HcRhPortStatus1 + p * 4) / 4] =
                (p < s_ndp) ? PORT_PPS : 0u;
    }
}

/* The controller, running on its own thread.
 *
 * It has to be its own thread for a reason that is easy to get wrong: the
 * guest register file is thread-local, so setting g_esp to a worker stack on
 * the guest's thread would overwrite the guest's own stack pointer mid-call.
 * A separate thread has its own copy, and it also happens to be what the
 * hardware does -- an interrupt arrives when the controller decides, not when
 * the driver next reads a register.
 *
 * ponytail: one delivery, of the root hub status change that is already
 * pending from bring-up. There is nothing behind it yet -- no descriptor list
 * walking, so an enumeration attempt has nothing to answer it -- and the point
 * of this delivery is to find out what the driver does when it finally gets
 * the interrupt it has been waiting for. Repeat delivery and the transfer
 * lists come after that answer, not before it.
 */
void xbox_guest_pin(int interrupt);     /* win32_compat.c */

/* Connect or disconnect pad `d` on its port, and tell the driver. */
static void ohci_plug(OhciController *hc, unsigned d, int on)
{
    uint32_t *ps = &hc->reg[(HcRhPortStatus1 + s_dev_port[d] * 4) / 4];

    usb_gamepad_reset((int)d);
    memset(&s_ctrl[d], 0, sizeof s_ctrl[d]);
    s_ctrl[d].len = -1;
    s_dev_plugged[d] = on;
    if (on) {
        *ps |= PORT_CCS | PORT_CSC;
    } else {
        if (*ps & PORT_PES)
            *ps |= PORT_PESC;
        *ps = (*ps & ~(PORT_CCS | PORT_PES)) | PORT_CSC;
    }
    hc->reg[HcInterruptStatus / 4] |= INTR_RHSC;
}

static DWORD WINAPI ohci_thread(LPVOID unused)
{
    /* This thread calls recompiled code, so it needs what any thread running
     * recompiled code needs: its own TIB. The guest register set is already
     * thread-local and the ISR gets a worker stack, but fs:[0] is the SEH
     * chain head and fs:[4] reaches the CRT's per-thread data -- and a guest
     * function with an SEH prologue on a thread whose g_fs_base is zero
     * dereferences null before it executes a line of its own body. That is
     * what killed the process here, two interrupts in, with no fault report
     * because the fault was in the runtime rather than in the title. */
    unsigned waited = 0;
    int plugged = 0;
    uint32_t last_status = 0;
    unsigned repeats = 0;
    unsigned held_off = 0;
    int      held_off_warned = 0, held_off_forced = 0;
    unsigned last_ack = 0;
    unsigned hotplug_tick = 0;

    (void)unused;
    xbox_guest_pin(1);             /* the ISR runs guest code: guest core, above it */
    {
        uint32_t tib = xbox_AllocThreadTib();
        if (!tib) {
            fprintf(stderr, "  [OHCI0] no TIB for the controller thread; "
                            "not delivering interrupts\n");
            fflush(stderr);
            return 0;
        }
        g_fs_base = tib;
    }

    for (;;) {
        OhciController *hc = &s_hc[s_device_hc];
        uint32_t control, enable, status;

        Sleep(OHCI_TICK_MS);
        control = hc->reg[HcControl / 4];
        enable  = hc->reg[HcInterruptEnable / 4];

        /* Operational is HCFS == 10b in bits 7:6. Interrupting a controller
         * the driver has not started yet is not a test of anything. */
        if ((control & 0xC0u) != 0x80u) {
            /* No deadline: a slow card (the Switch's SD) pushes the title's
             * USB bring-up well past 30 s, and giving up then means the pad
             * never arrives. Say so once, and keep waiting. */
            if (++waited == 30000u / OHCI_TICK_MS)
                fprintf(stderr, "  [OHCI0] not started after 30 s; still waiting\n");
            continue;
        }
        if (!(enable & INTR_MIE))
            continue;

        /* Plug the device in once, after the driver is running and listening.
         * Presenting it earlier does not work: the driver clears the connect
         * change during its own bring-up scan, and a reset clears interrupt
         * status, so a device that was always there is one that never
         * arrives. */
        if (!plugged && (enable & INTR_RHSC)) {
            ohci_plug(hc, 0, 1);
            plugged = 1;
            fprintf(stderr, "  [OHCI0] operational after %u ms; device "
                            "arriving on port %u\n", waited * OHCI_TICK_MS,
                    s_dev_port[0] + 1);
            fflush(stderr);
        }

        /* The other pads follow their host pads, checked every ~250 ms --
         * and only once pad 0 is addressed, so the driver enumerates one
         * device at a time as it would after a real hot plug. */
        if (plugged && s_ndev > 1 && ++hotplug_tick >= 250u / OHCI_TICK_MS
                && usb_gamepad_address(0)) {
            unsigned d;
            hotplug_tick = 0;
            for (d = 1; d < s_ndev; d++) {
                int want = usb_gamepad_connected((int)d);
                if (want != s_dev_plugged[d]) {
                    ohci_plug(hc, d, want);
                    fprintf(stderr, "  [OHCI%d] pad %u %s port %u\n",
                            hc->index, d + 1,
                            want ? "plugged into" : "unplugged from",
                            s_dev_port[d] + 1);
                    fflush(stderr);
                }
            }
        }

        /* The frame clock.
         *
         * INTR_SF was defined and never raised, and HcFmNumber only moved when
         * something read it. That is enough for a driver that polls, and not
         * enough for one that waits: USB enumeration is full of delays counted
         * in frames -- the recovery time after SET_ADDRESS is the first -- and
         * the Xbox stack enables StartOfFrame precisely to count them. Without
         * a frame ever starting, enumeration stops one transfer past
         * SET_ADDRESS with the driver waiting for time to pass.
         *
         * Twenty frames a tick because a frame is 1 ms and this loop sleeps
         * 20. The count is what drivers compare; the rate is what they feel,
         * and both are closer to right this way than a counter that never
         * moves. */
        {
            uint32_t hcca = hc->reg[HcHCCA / 4];
            static uint32_t shown_hcca;

            if (hcca && hcca != shown_hcca) {
                shown_hcca = hcca;
                fprintf(stderr, "  [OHCI%d] HcHCCA = 0x%08X, HcControlHeadED = 0x%08X\n",
                        hc->index, hcca, hc->reg[0x20 / 4]);
                fflush(stderr);
            }
            hc->reg[HcFmNumber / 4] =
                (hc->reg[HcFmNumber / 4] + OHCI_TICK_MS) & 0xFFFFu;
            /* HccaFrameNumber is 16 bits at +0x80 with a pad above it that the
             * controller zeroes, so a dword write is what hardware does. */
            if (hcca)
                wr32(hcca + 0x80, hc->reg[HcFmNumber / 4]);
            hc->reg[HcInterruptStatus / 4] |= INTR_SF;
        }

        /* Be the bus master. ControlListEnable in HcControl says the driver
         * wants the list walked; ControlListFilled says it has put something
         * on it. Walking on the tick rather than only when CLF is written
         * costs a read of a guest dword and means a descriptor queued without
         * rewriting CLF is still moved -- which is legal, and drivers do it. */
        /* Not while the driver still owes us an acknowledgement.
         *
         * HccaDoneHead belongs to the driver from the moment WDH is set
         * until it clears it. Writing a second done list over the first
         * loses every descriptor on it -- the driver walks a chain whose
         * links now point into the new list, and the structures it keeps
         * alongside go with it. At a twenty-millisecond tick that overlap
         * was rare enough to look like bad luck; at four it corrupted the
         * host controller's pending list within a second or two of the
         * gamepad's reports starting. Leaving the descriptors on their
         * endpoints for another pass costs a few milliseconds of latency
         * and is what the controller is specified to do. */
        if (hc->reg[HcInterruptStatus / 4] & INTR_WDH)
            goto deliver;

        /* PeriodicListEnable, bit 2 of HcControl. */
        if (control & 0x04u) {
            if (!hc->ple_seen) {
                hc->ple_seen = 1;
                fprintf(stderr, "  [OHCI%d] periodic list enabled "
                        "(HcControl=%08X HCCA=%08X)\n",
                        hc->index, control, hc->reg[HcHCCA / 4]);
                fflush(stderr);
            }
            ohci_run_periodic_list(hc);
        }

        /* BulkListEnable, bit 5. Nothing on this device uses bulk, but the
         * list is walked the same way and a driver that puts a transfer
         * there is owed the same service. */
        if ((control & 0x20u)
         && guest_ok(hc->reg[HcBulkHeadED / 4] & ED_PTR_MASK, 16)) {
            uint32_t done_head = 0;
            if (ohci_walk_eds(hc, hc->reg[HcBulkHeadED / 4] & ED_PTR_MASK,
                              &done_head)) {
                ohci_publish_done(hc, done_head);
                hc->reg[HcCommandStatus / 4] &= ~0x04u;   /* BLF consumed */
            }
        }

        if ((control & 0x10u)
         && guest_ok(hc->reg[HcControlHeadED / 4] & ED_PTR_MASK, 16)) {
            if (ohci_run_control_list(hc))
                hc->reg[HcCommandStatus / 4] &= ~0x02u;   /* CLF consumed */
        }

        /* Level-triggered, which is what OHCI is: while an enabled source is
         * set, the line is asserted. The handler clears the status bit, so
         * this stops on its own -- and if it ever does not, the cap below says
         * so rather than spinning the ISR forever. */
        ohci_flush_done(hc);    /* publish TDs held while WDH was set */
    deliver:
        status = hc->reg[HcInterruptStatus / 4] & enable & 0x7Fu;
        if (!status)
            continue;

        /* Bounded, because the mask is a model and not the hardware.
         *
         * The depth is a count of raise/lower pairs across every thread, and
         * one unmatched raise anywhere leaves the gate shut for the rest of
         * the run -- which is how this first showed up: no interrupt was ever
         * delivered and enumeration stopped at two empty control EDs. Real
         * hardware is never masked for 80 ms, so past that the line is
         * asserted anyway. The common case still holds the ISR out of the
         * guest's critical section; the pathological case costs a delay
         * instead of the device. */
        if (xbox_IrqlBlocksInterrupts() && ++held_off <= OHCI_IRQ_HOLDOFF) {
            if (!held_off_warned) {
                held_off_warned = 1;
                fprintf(stderr, "  [OHCI%d] irq held off by guest IRQL "
                        "(depth %d, status=0x%02X)\n",
                        hc->index, xbox_IrqlRaisedCount(), status);
                fflush(stderr);
            }
            continue;
        }
        if (held_off > OHCI_IRQ_HOLDOFF && !held_off_forced) {
            held_off_forced = 1;
            fprintf(stderr, "  [OHCI%d] guest IRQL never dropped (depth %d); "
                    "delivering anyway\n", hc->index, xbox_IrqlRaisedCount());
            fflush(stderr);
        }
        held_off = 0;

        /* A stuck source is one the handler never clears. Repeating the
         * same status value is not that.
         *
         * This counted deliveries of an unchanged status and gave up at
         * 200, and a working gamepad trips that in two seconds: the pad
         * reports at 100 Hz, every report completes a transfer descriptor,
         * every completion raises WritebackDoneHead, and every one of them
         * is the same status value. The driver was acknowledging each one
         * -- 141 writes to HcInterruptStatus in the run this was found on
         * -- and the count climbed anyway, because nothing reset it.
         *
         * What distinguishes the two is whether the driver wrote the
         * register at all between one delivery and the next. */
        if (status == last_status && hc->ack_seq == last_ack) {
            if (++repeats > 200) {
                fprintf(stderr, "  [OHCI%d] status %08X delivered 200 times "
                                "with no acknowledgement; stopping\n",
                        hc->index, status);
                fflush(stderr);
                break;
            }
        } else {
            last_status = status;
            last_ack    = hc->ack_seq;
            repeats     = 0;
        }
        ohci_raise(hc, status);
    }
    return 0;
}

static uint32_t ohci_mmio_rd(void *dev, uint32_t off, unsigned size);
static void ohci_mmio_wr(void *dev, uint32_t off, uint32_t val, unsigned size);

void xbox_OhciInit(void)
{
    static int done;

    if (done)
        return;
    done = 1;

    /* Opt-in. Without a descriptor list walker behind it a driver that finds
     * a port has nothing to enumerate, so this must not change how a title
     * behaves until the rest of it exists. */
    if (!getenv("RECOMP_USB"))
        return;

    s_enabled = 1;
    s_trace   = getenv("RECOMP_USB_TRACE") != NULL;
    {
        const char *hcspec = getenv("RECOMP_USB_HC");
        const char *ndpspec = getenv("RECOMP_USB_NDP");
        s_device_hc = (hcspec && atoi(hcspec) == 1) ? 1 : 0;
        if (ndpspec) {
            int n = atoi(ndpspec);
            if (n >= 1 && n <= 4) s_ndp = (unsigned)n;
        }
    }
    {
        /* Which port a pad appears on decides which player XAPI makes it,
         * and a title that reads "player 1" looks at slot 0. RECOMP_USB_PORT
         * (pad 1) and RECOMP_USB_PORT2 (pad 2) pick them, 0-based, so the
         * mapping can be found by measurement rather than assumed.
         * RECOMP_USB_PADS=1 leaves the second pad out. */
        const char *p1 = getenv("RECOMP_USB_PORT");
        const char *p2 = getenv("RECOMP_USB_PORT2");
        const char *np = getenv("RECOMP_USB_PADS");
        s_dev_port[0] = p1 ? (unsigned)atoi(p1) : 0u;
        if (s_dev_port[0] >= s_ndp) s_dev_port[0] = s_ndp - 1u;
        s_dev_port[1] = p2 ? (unsigned)atoi(p2) : (s_dev_port[0] ? 0u : 1u);
        s_ndev = (np && atoi(np) == 1) ? 1u : 2u;
        if (s_ndp < 2 || s_dev_port[1] >= s_ndp || s_dev_port[1] == s_dev_port[0])
            s_ndev = 1;
        s_ctrl[0].len = s_ctrl[1].len = -1;
    }
    ohci_reset(&s_hc[0], XBOX_OHCI0_BASE, 0);
    ohci_reset(&s_hc[1], XBOX_OHCI1_BASE, 1);

#if defined(_WIN32) && !defined(XBOXRECOMP_SDL_HOST)
    /* The registers have to fault to be answered. The MCPX aperture is mapped
     * as plain committed memory, so both blocks are made inaccessible here and
     * the title's VEH routes the faults back to xbox_OhciHandleMmio.
     *
     * A failed protect switches the model off rather than leaving it half on:
     * a controller whose registers read as zero out of RAM is exactly the
     * situation this exists to end, and it would look identical. */
    {
        ptrdiff_t off = xbox_GetMemoryOffset();
        int i;

        if (!off) {
            s_enabled = 0;
            fprintf(stderr, "  OHCI: guest memory not mapped yet; disabled\n");
            return;
        }
        for (i = 0; i < 2; i++) {
            DWORD old_protect;
            LPVOID at = (LPVOID)((uintptr_t)off + s_hc[i].base);
            if (!VirtualProtect(at, XBOX_OHCI_SIZE, PAGE_NOACCESS,
                                &old_protect)) {
                s_enabled = 0;
                fprintf(stderr, "  OHCI: cannot trap 0x%08X (error %lu); "
                                "disabled\n", s_hc[i].base, GetLastError());
                return;
            }
        }
    }
#endif

#if !defined(_WIN32) || defined(XBOXRECOMP_SDL_HOST)
    /* No fault handling on this host: the registers stay plain memory and the
     * title's XPP code, lifted with --mmio-sections XPP, reaches the model
     * through the runtime's MMIO accessors instead. */
    xbox_MmioRegister(XBOX_OHCI0_BASE, XBOX_OHCI0_BASE + XBOX_OHCI_SIZE,
                      ohci_mmio_rd, ohci_mmio_wr, &s_hc[0]);
    xbox_MmioRegister(XBOX_OHCI1_BASE, XBOX_OHCI1_BASE + XBOX_OHCI_SIZE,
                      ohci_mmio_rd, ohci_mmio_wr, &s_hc[1]);
#endif

    fprintf(stderr, "  OHCI: two controllers at 0x%08X and 0x%08X, "
                    "%u ports each, %u pad(s) on HC%d\n",
            XBOX_OHCI0_BASE, XBOX_OHCI1_BASE, s_ndp, s_ndev, s_device_hc);
    fflush(stderr);

    {
        HANDLE th = CreateThread(NULL, 0, ohci_thread, NULL, 0, NULL);
        if (th)
            CloseHandle(th);
    }
}

static uint32_t ohci_mmio_rd(void *dev, uint32_t off, unsigned size)
{
    return (uint32_t)ohci_read(dev, off, (int)size);
}

static void ohci_mmio_wr(void *dev, uint32_t off, uint32_t val, unsigned size)
{
    ohci_write(dev, off, val, (int)size);
}

static OhciController *hc_for(uint32_t va)
{
    int i;

    if (!s_enabled)
        return NULL;
    for (i = 0; i < 2; i++)
        if (va >= s_hc[i].base && va < s_hc[i].base + XBOX_OHCI_SIZE)
            return &s_hc[i];
    return NULL;
}

int xbox_OhciOwnsAddress(uint32_t xbox_va)
{
    return hc_for(xbox_va) != NULL;
}

int xbox_OhciHandleMmio(void *ctx, uint32_t xbox_va)
{
#if defined(_WIN32) && !defined(XBOXRECOMP_SDL_HOST)
    OhciController *hc = hc_for(xbox_va);
    int ok;

    if (!hc)
        return 0;
    ok = mmio_emulate((PCONTEXT)ctx, xbox_va - hc->base, hc,
                      ohci_read, ohci_write);
    if (!ok && hc->decode_fail++ < 20) {
        const uint8_t *ip = (const uint8_t *)((PCONTEXT)ctx)->Rip;
        fprintf(stderr, "  [OHCI%d] undecoded access at +0x%03X: "
                        "%02X %02X %02X %02X %02X %02X\n",
                hc->index, xbox_va - hc->base,
                ip[0], ip[1], ip[2], ip[3], ip[4], ip[5]);
        fflush(stderr);
    }
    return ok;
#else
    (void)ctx; (void)xbox_va;
    return 0;
#endif
}

void xbox_OhciReport(void)
{
    int i;

    if (!s_enabled)
        return;
    for (i = 0; i < 2; i++)
        fprintf(stderr, "  [OHCI%d] %u reads, %u writes, %u undecoded; "
                        "HcControl=%08X HcIntStatus=%08X port1=%08X\n",
                i, s_hc[i].reads, s_hc[i].writes, s_hc[i].decode_fail,
                s_hc[i].reg[HcControl / 4],
                s_hc[i].reg[HcInterruptStatus / 4],
                s_hc[i].reg[HcRhPortStatus1 / 4]);
    fflush(stderr);
}
